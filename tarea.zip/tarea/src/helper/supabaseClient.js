import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://qbreocyepyqpmnttcdqt.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFicmVvY3llcHlxcG1udHRjZHF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUyNjQyNDAsImV4cCI6MjA2MDg0MDI0MH0.D4mY2T7EpdRRwUJVgqWZ5VBepqVOQhXas-sx9pILoUw';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

export default supabase;