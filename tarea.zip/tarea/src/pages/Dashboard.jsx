import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import supabase from '../helper/supabaseClient';
import NavBar from './components/NavBar';
import Footer from './components/Footer';
import CustomButton from './components/CustomButton';

function Dashboard() {
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [info, setInfo] = useState('This is some information from a variable.');

  useEffect(() => {
    const fetchUsername = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data, error } = await supabase
          .from('ID')
          .select('username')
          .eq('email', user.email)
          .single();
        if (data && data.username) {
          setUsername(data.username);
        }
        if (error) {
          console.error('Error fetching username:', error.message);
        }
      }
    };
    fetchUsername();
  }, []);

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.log('Error signing out:', error.message);
    } else {
      console.log('Signed out successfully');
      navigate('/login');
    }
  };

  return (
    <>
      <NavBar />
      <div style={{
        minHeight: '80vh',
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        background: 'linear-gradient(135deg, #f8ffae 0%, #43c6ac 100%)'
      }}>
        <h2 style={{
          fontFamily: 'Segoe UI, sans-serif',
          color: '#2d3a4b',
          fontWeight: 700,
          marginBottom: '1rem'
        }}>
          Welcome to your Dashboard
        </h2>
        {username && (
          <h3 style={{
            color: '#4f8cff',
            marginBottom: '2rem',
            fontWeight: 600
          }}>
            Hello, {username}!
          </h3>
        )}
        {/* Paragraph displaying info variable */}
        <p style={{ marginBottom: '1rem', color: '#222', fontSize: '1.1rem' }}>{info}</p>
        {/* Button to update info variable */}
        <CustomButton onClick={() => setInfo('The variable value has been updated!')}>
          Update Info
        </CustomButton>
        <div style={{ display: 'flex', gap: '1.5rem', marginBottom: '2rem' }}>
          <button
            onClick={() => navigate('/')}
            style={{
              padding: '0.7rem 1.8rem',
              background: '#fff',
              color: '#4f8cff',
              border: '2px solid #4f8cff',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '1rem',
              cursor: 'pointer',
              transition: 'background 0.2s, color 0.2s'
            }}
            onMouseOver={e => {
              e.currentTarget.style.background = '#4f8cff';
              e.currentTarget.style.color = '#fff';
            }}
            onMouseOut={e => {
              e.currentTarget.style.background = '#fff';
              e.currentTarget.style.color = '#4f8cff';
            }}
          >
            Go Home
          </button>
          <button
            onClick={signOut}
            style={{
              padding: '0.7rem 1.8rem',
              background: '#ff7675',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '1rem',
              cursor: 'pointer',
              transition: 'background 0.2s'
            }}
            onMouseOver={e => e.currentTarget.style.background = '#d63031'}
            onMouseOut={e => e.currentTarget.style.background = '#ff7675'}
          >
            Sign Out
          </button>
        </div>
        <div style={{
          background: '#fff',
          borderRadius: '12px',
          padding: '1.5rem 2rem',
          boxShadow: '0 2px 12px rgba(44, 62, 80, 0.08)',
          textAlign: 'center',
          color: '#636e72'
        }}>
          <p>
            This is your personal dashboard. Here you can manage your account, view your profile, and explore more features coming soon!
          </p>
          <button
            style={{
              marginTop: '1rem',
              padding: '0.6rem 1.5rem',
              background: '#2ecc71',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '1rem',
              cursor: 'pointer',
              transition: 'background 0.2s'
            }}
            onMouseOver={e => e.currentTarget.style.background = '#229954'}
            onMouseOut={e => e.currentTarget.style.background = '#2ecc71'}
            onClick={() => alert('More features coming soon!')}
          >
            Explore Features
          </button>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default Dashboard;
