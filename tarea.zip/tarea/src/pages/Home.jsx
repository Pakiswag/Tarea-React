import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      background: 'linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%)'
    }}>
      <h1 style={{
        fontFamily: 'Segoe UI, sans-serif',
        color: '#2d3a4b',
        marginBottom: '2rem',
        fontWeight: 700,
        letterSpacing: '1px'
      }}>
        Welcome to the App!
      </h1>
      <div style={{ display: 'flex', gap: '2rem' }}>
        <Link
          to="/register"
          style={{
            padding: '0.75rem 2rem',
            background: '#4f8cff',
            color: '#fff',
            borderRadius: '8px',
            textDecoration: 'none',
            fontWeight: 600,
            fontSize: '1.1rem',
            boxShadow: '0 2px 8px rgba(79,140,255,0.15)',
            transition: 'background 0.2s, transform 0.2s',
          }}
          onMouseOver={e => e.currentTarget.style.background = '#3466af'}
          onMouseOut={e => e.currentTarget.style.background = '#4f8cff'}
        >
          Register
        </Link>
        <Link
          to="/login"
          style={{
            padding: '0.75rem 2rem',
            background: '#2ecc71',
            color: '#fff',
            borderRadius: '8px',
            textDecoration: 'none',
            fontWeight: 600,
            fontSize: '1.1rem',
            boxShadow: '0 2px 8px rgba(46,204,113,0.15)',
            transition: 'background 0.2s, transform 0.2s',
          }}
          onMouseOver={e => e.currentTarget.style.background = '#229954'}
          onMouseOut={e => e.currentTarget.style.background = '#2ecc71'}
        >
          Login
        </Link>
      </div>
    </div>
  );
}

export default Home;
