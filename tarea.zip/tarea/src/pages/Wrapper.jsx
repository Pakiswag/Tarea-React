
import { Navigate } from "react-router-dom";
import supabase from "../helper/supabaseClient";
import { useEffect, useState } from "react";

function Wrapper({ children }) {
    const [authenticated, setAuthenticated] = useState(false);
    const [Loading, setLoading] = useState(true);
    useEffect(() => {
        const getSession = async () => {
            const { 
                data: { session },
            } = await supabase.auth.getSession();
           setAuthenticated(!!session);
           setLoading(false);
        };
        getSession();
    }, []);    

    if (Loading) {
        return <div>Loading...</div>;
    }else  if (authenticated) {
        return children;
    }
    return <Navigate to="/login" />;
};

export default Wrapper;