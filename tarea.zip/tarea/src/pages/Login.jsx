import React, { useState } from 'react';
import supabase from '../helper/supabaseClient';
import { Link, useNavigate } from 'react-router-dom';

function Login() {
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [message, setMessage] = useState("");
    const handleSubmit = async (event) => {
      event.preventDefault();
      setMessage("");
      const {data, error} = await supabase.auth.signInWithPassword({ 
          email: email,
          password: password,
          });
      if (error) {
          setMessage(error.message);
          setEmail('');
          setPassword('');  
          return;
      }
      if (data) {
          setMessage('Logged In, successfully');
          navigate('/dashboard');
          return null;
      } else {
          setMessage('Something went wrong, please try again later');
      }
    }; 
   return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      background: 'linear-gradient(135deg, #e0eafc 0%, #cfdef3 100%)'
    }}>
      <div style={{
        background: '#fff',
        borderRadius: '14px',
        boxShadow: '0 2px 16px rgba(44, 62, 80, 0.10)',
        padding: '2.5rem 2.5rem 2rem 2.5rem',
        minWidth: '340px',
        textAlign: 'center'
      }}>
        <h2 style={{
          fontFamily: 'Segoe UI, sans-serif',
          color: '#2d3a4b',
          fontWeight: 700,
          marginBottom: '1.5rem'
        }}>
          Log In
        </h2>
        {message && <span style={{ color: '#e17055', fontWeight: 500 }}>{message}</span>}
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1rem' }}>
          <input
            onChange={(e) => setEmail(e.target.value)}
            value={email}
            type="email"
            placeholder='Email'
            required
            style={{
              padding: '0.7rem',
              borderRadius: '8px',
              border: '1px solid #b2bec3',
              fontSize: '1rem'
            }}
          />
          <input
            onChange={(e) => setPassword(e.target.value)}
            value={password}
            type="password"
            placeholder='Password'
            required
            style={{
              padding: '0.7rem',
              borderRadius: '8px',
              border: '1px solid #b2bec3',
              fontSize: '1rem'
            }}
          />
          <button
            type="submit"
            style={{
              padding: '0.7rem',
              background: '#2ecc71',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              fontWeight: 600,
              fontSize: '1rem',
              cursor: 'pointer',
              transition: 'background 0.2s'
            }}
            onMouseOver={e => e.currentTarget.style.background = '#229954'}
            onMouseOut={e => e.currentTarget.style.background = '#2ecc71'}
          >
            Log In
          </button>
        </form>
        <div style={{ marginTop: '1.5rem', fontSize: '1rem' }}>
          <span>Don't have an account?</span>
          <Link to="/register" style={{ color: '#4f8cff', fontWeight: 600, marginLeft: '0.5rem', textDecoration: 'none' }}>
            Create an Account
          </Link>
        </div>
        <button
          style={{
            marginTop: '1.5rem',
            padding: '0.6rem 1.5rem',
            background: '#fff',
            color: '#4f8cff',
            border: '2px solid #4f8cff',
            borderRadius: '8px',
            fontWeight: 600,
            fontSize: '1rem',
            cursor: 'pointer',
            transition: 'background 0.2s, color 0.2s'
          }}
          onClick={() => navigate('/')}
          onMouseOver={e => {
            e.currentTarget.style.background = '#4f8cff';
            e.currentTarget.style.color = '#fff';
          }}
          onMouseOut={e => {
            e.currentTarget.style.background = '#fff';
            e.currentTarget.style.color = '#4f8cff';
          }}
        >
          Go Home
        </button>
      </div>
    </div>
   );
}

export default Login;
