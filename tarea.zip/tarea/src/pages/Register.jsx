import React, { useState } from 'react';
import supabase from '../helper/supabaseClient';
import { Link, useNavigate } from 'react-router-dom';

function Register() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [message, setMessage] = useState("");
  const [showUsernameInput, setShowUsernameInput] = useState(false);
  const [registeredEmail, setRegisteredEmail] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (event) => {
    event.preventDefault();
    setMessage("");
    const { data, error } = await supabase.auth.signUp({ 
      email: email,
      password: password,
    });
    if (error) {
      setMessage(error.message);
      return;
    }
    if (data) {
      setMessage('Account created! Please enter your username.');
      setShowUsernameInput(true);
      setRegisteredEmail(email);
    } else {
      setMessage('Something went wrong, please try again later');
    }
    setEmail('');
    setPassword('');
  };

  const handleUsernameSubmit = async (event) => {
    event.preventDefault();
    const { error: insertError } = await supabase
      .from('ID')
      .insert([
        {
          username: username,
          email: registeredEmail,
        }
      ]);
    if (insertError) {
      setMessage('Failed to save username.');
    } else {
      setMessage('Username saved successfully!');
      setShowUsernameInput(false);
    }
    setUsername('');
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      background: 'linear-gradient(135deg, #f8ffae 0%, #43c6ac 100%)'
    }}>
      <div style={{
        background: '#fff',
        borderRadius: '14px',
        boxShadow: '0 2px 16px rgba(44, 62, 80, 0.10)',
        padding: '2.5rem 2.5rem 2rem 2.5rem',
        minWidth: '340px',
        textAlign: 'center'
      }}>
        <h2 style={{
          fontFamily: 'Segoe UI, sans-serif',
          color: '#2d3a4b',
          fontWeight: 700,
          marginBottom: '1.5rem'
        }}>
          Register
        </h2>
        {message && <span style={{ color: '#e17055', fontWeight: 500 }}>{message}</span>}
        <br />
        {!showUsernameInput ? (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1rem' }}>
            <input
              onChange={(e) => setEmail(e.target.value)}
              value={email}
              type="email"
              placeholder="Email"
              required
              style={{
                padding: '0.7rem',
                borderRadius: '8px',
                border: '1px solid #b2bec3',
                fontSize: '1rem'
              }}
            />
            <input
              onChange={(e) => setPassword(e.target.value)}
              value={password}
              type="password"
              placeholder="Password"
              required
              style={{
                padding: '0.7rem',
                borderRadius: '8px',
                border: '1px solid #b2bec3',
                fontSize: '1rem'
              }}
            />
            <button
              type="submit"
              style={{
                padding: '0.7rem',
                background: '#4f8cff',
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                fontWeight: 600,
                fontSize: '1rem',
                cursor: 'pointer',
                transition: 'background 0.2s'
              }}
              onMouseOver={e => e.currentTarget.style.background = '#3466af'}
              onMouseOut={e => e.currentTarget.style.background = '#4f8cff'}
            >
              Create Account
            </button>
          </form>
        ) : (
          <form onSubmit={handleUsernameSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', marginTop: '1rem' }}>
            <input
              onChange={(e) => setUsername(e.target.value)}
              value={username}
              type="text"
              placeholder="Enter your username"
              required
              style={{
                padding: '0.7rem',
                borderRadius: '8px',
                border: '1px solid #b2bec3',
                fontSize: '1rem'
              }}
            />
            <button
              type="submit"
              style={{
                padding: '0.7rem',
                background: '#2ecc71',
                color: '#fff',
                border: 'none',
                borderRadius: '8px',
                fontWeight: 600,
                fontSize: '1rem',
                cursor: 'pointer',
                transition: 'background 0.2s'
              }}
              onMouseOver={e => e.currentTarget.style.background = '#229954'}
              onMouseOut={e => e.currentTarget.style.background = '#2ecc71'}
            >
              Save Username
            </button>
          </form>
        )}
        <div style={{ marginTop: '1.5rem', fontSize: '1rem' }}>
          <span>Already have an account?</span>
          <Link to="/login" style={{ color: '#4f8cff', fontWeight: 600, marginLeft: '0.5rem', textDecoration: 'none' }}>
            Login
          </Link>
        </div>
        <button
          style={{
            marginTop: '1.5rem',
            padding: '0.6rem 1.5rem',
            background: '#fff',
            color: '#4f8cff',
            border: '2px solid #4f8cff',
            borderRadius: '8px',
            fontWeight: 600,
            fontSize: '1rem',
            cursor: 'pointer',
            transition: 'background 0.2s, color 0.2s'
          }}
          onClick={() => navigate('/')}
          onMouseOver={e => {
            e.currentTarget.style.background = '#4f8cff';
            e.currentTarget.style.color = '#fff';
          }}
          onMouseOut={e => {
            e.currentTarget.style.background = '#fff';
            e.currentTarget.style.color = '#4f8cff';
          }}
        >
          Go Home
        </button>
      </div>
    </div>
  );
}

export default Register;
