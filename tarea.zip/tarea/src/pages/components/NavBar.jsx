import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import supabase from '../../helper/supabaseClient';

function NavBar() {
  const location = useLocation();
  const navigate = useNavigate();

  
  if (location.pathname === '/login') return null;

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/login');
  };

  return (
    <nav style={{
      width: '100%',
      background: '#4f8cff',
      padding: '1rem 2rem',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      color: '#fff',
      marginBottom: '2rem'
    }}>
      <div>
        <Link to="/dashboard" style={{ color: '#fff', textDecoration: 'none', fontWeight: 700, fontSize: '1.2rem', marginRight: '2rem' }}>
          Dashboard
        </Link>
        <Link to="/" style={{ color: '#fff', textDecoration: 'none', fontWeight: 500, marginRight: '1.5rem' }}>
          Home
        </Link>
      </div>
      <button
        onClick={handleLogout}
        style={{
          background: '#fff',
          color: '#4f8cff',
          border: 'none',
          borderRadius: '8px',
          padding: '0.5rem 1.2rem',
          fontWeight: 600,
          cursor: 'pointer',
          transition: 'background 0.2s, color 0.2s'
        }}
        onMouseOver={e => {
          e.currentTarget.style.background = '#d63031';
          e.currentTarget.style.color = '#fff';
        }}
        onMouseOut={e => {
          e.currentTarget.style.background = '#fff';
          e.currentTarget.style.color = '#4f8cff';
        }}
      >
        Logout
      </button>
    </nav>
  );
}

export default NavBar;
