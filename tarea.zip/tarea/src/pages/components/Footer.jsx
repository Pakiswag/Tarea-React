import React from 'react';

function Footer() {
  return (
    <footer style={{
      width: '100%',
      background: '#2d3a4b',
      color: '#fff',
      textAlign: 'center',
      padding: '1rem 0',
      position: 'fixed',
      left: 0,
      bottom: 0,
      zIndex: 100
    }}>
      &copy; {new Date().getFullYear()} My Dashboard App. All rights reserved. Francisco Sauceda Moreno A01722325
    </footer>
  );
}

export default Footer;
