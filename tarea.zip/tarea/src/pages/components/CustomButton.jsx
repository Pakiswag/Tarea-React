import React from 'react';

function CustomButton({ children, onClick, className = '', ...props }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`
        px-7 py-3
        bg-blue-500
        text-white
        rounded-lg
        font-semibold
        text-base
        transition
        duration-150
        ease-in-out
        shadow
        hover:bg-blue-700
        hover:shadow-lg
        hover:ring-2
        hover:ring-blue-300
        active:scale-95
        focus:outline-none
        focus:ring-2
        focus:ring-blue-400
        ${className}
      `}
      {...props}
    >
      {children}
    </button>
  );
}

export default CustomButton;
