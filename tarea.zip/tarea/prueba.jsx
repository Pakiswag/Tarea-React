import supabase from './src/supabase-client';
import { useEffect } from 'react';

function Test() {

    useEffect(() => {
        fetchMetrics();
    }, []);

    async function fetchMetrics() {
        const { data, error } = await supabase
            .from('id')
            .select(`
                username,
                password,
                created_at,
                email
            `);

        console.log(data, error);
    }

  
}

export default Test;